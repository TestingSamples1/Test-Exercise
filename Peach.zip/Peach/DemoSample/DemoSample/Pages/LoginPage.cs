﻿using DemoSample.CoreUI;
using DemoSample.Extensions;
using DemoSample.TestData;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoSample.Pages
{
    public class LoginPage
    {
        protected WebDriverSupport _driverSupport = new WebDriverSupport();

        string name = TestData.TestData.GenerateName(8);

        #region loginPageElements

        [FindsBy(How = How.LinkText, Using = "login")]
        private IWebElement loginButton { get; set; }

        [FindsBy(How = How.Name, Using = "acct")]
        private IList<IWebElement> newUserNameField { get; set; }

        [FindsBy(How = How.Name, Using = "pw")]
        private IList<IWebElement> newPassword { get; set; }

        [FindsBy(How = How.XPath, Using = "//input[@value='create account']")]
         private IWebElement createAccount { get; set; }

        protected IWebElement verifyLoginName(string name) =>
         _driverSupport.FindNewElement(By.XPath($"//*[@id='me'][text()='{name}']"));

        #endregion

        #region loginPageActions
        public void EnterLoginDetails(string name, string password)
        {
            loginButton.Click();
            newUserNameField.First().WaitUntilDisplayed(2);
            newUserNameField.First().EnterText(name);
            newPassword.First().EnterText(password);
            createAccount.Click();
        }

        public void NewUserDetails()
        {
           
            loginButton.Click();
            newUserNameField.Last().Click();
            newUserNameField.Last().EnterText(name);
            newPassword.Last().EnterText("password");

        }
        public void CreateAccount()
        {
            createAccount.Click();
        }

        public void verifyLogin()
        {
            verifyLoginName(name);
        }
        #endregion

    }
}
