﻿# Setup variables

$root = (get-item $pwd.path ).parent.FullName

$Project = "DemoSample"

$FeatureDirectory = "$root\$Project\Scenarios"

$OutputDirectory = "$root\Docs\$Project\Html"

$DocumentationFormat = "html"

 

# Import the Pickles-comandlet

Import-Module $root\packages\Pickles.2.20.1\tools\PicklesDoc.Pickles.Powershell.dll

 

# Call pickles

Pickle-Features -FeatureDirectory $FeatureDirectory `
-OutputDirectory $OutputDirectory `
-DocumentationFormat $DocumentationFormat